KiCad Footprint and Component for ESP32-Wrover
==

This is an astonishingly well-specced and well-priced chip (see the datasheet included). In addition to the standard ESP32 modules (e.g. Wroom) it has an additional 4-8Mb of PSRAM allowing you to run things like Micropython (though I dunno who would want to run Python on this thing.).

I couldn't find a footprint, so working on the shoulders of others, I came up with this.

Status: TESTED

Happy Hacking!
